var express = require('express');
var router = express.Router();
const axios = require('axios')
const schemas = require('../classes/Schemas');
const ValidationMiddleware = require('../middleware/Middleware').ValidationMiddleware;

router.use(require('../middleware/Middleware').LoggingMiddleware); //adds logging on all routes listed below
var funds = require('../classes/funds');
var validator = require('../classes/ethAddressValidator');
var ethService = require('../classes/ethService');
var bscService = require('../classes/bscService');
var btcService = require('../classes/btcService');
var stripe = require('../classes/stripe');

var tokens = require('../classes/tokens');

router.post('/createPayment',ValidationMiddleware(schemas.approvePayment),funds.createPayment);
router.post('/stripeWebhook',funds.stripeWebhook);

router.get('/validateaddress/eth/:address',validator.validate);
router.get('/validateaddress/btc/:address',btcService.validateAddress);

router.get('/getbalance/eth/:address',ethService.getBalance);
router.get('/getbalance/bsc/:address',bscService.getBalance);
router.get('/getbalance/btc/:address',btcService.getBalance);


router.get('/getNewAddress',btcService.getNewAddress);

router.get('/tokenTransfer/:coin/:transactionId',tokens.tokenTransfer);
router.post('/tokenTransfer',ValidationMiddleware(schemas.tokenTransfer),tokens.tokenTransfer);

router.get('/getBtcNetworkInfo',btcService.getNetworkInfo);
router.get('/getBTCBalanceForOutSideWallet/:address',btcService.getBTCBalanceForOutSideWallet);
module.exports = router;

/* GET home page. */
router.get('/', function(req, res, next) {
  res.render('index');
});
router.get('/buy', function(req, res, next) {
  res.render('buy');
});
router.get('/address', function(req, res, next) {
  res.render('address_generation');
});


router.get('/login', function(req, res, next) {
  res.render('login');
});

router.get('/register', function(req, res, next) {
  res.render('register');
});

module.exports = router;
