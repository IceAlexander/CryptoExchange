/**
 * @swagger
 * /validateaddress/eth/{address}:
 *  get:
 *    parameters:
 *    - name: "address"
 *      in: "path"
 *      description: "validate any ETH address"
 *      type: "string"
 *      required: true
 *    summary: validate any ETH address
 *    description: to get information of given address valid or not
 *    responses:
 *      '200':
 *        description: response for given address
 * /validateaddress/btc/{address}:
 *  get:
 *    parameters:
 *    - name: "address"
 *      in: "path"
 *      description: "validate any BTC address"
 *      type: "string"
 *      required: true
 *    summary: validate any BTC address
 *    description: to get information of given address valid or not
 *    responses:
 *      '200':
 *        description: response for given address
 * /getbalance/eth/{address}:
 *  get:
 *    parameters:
 *    - name: "address"
 *      in: "path"
 *      description: "get available balance for any ETH address"
 *      type: "string"
 *      required: true
 *    summary: get available balance for any ETH address
 *    description: to get available balance information
 *    responses:
 *      '200':
 *        description: response for given address
 * /getbalance/bsc/{address}:
 *  get:
 *    parameters:
 *    - name: "address"
 *      in: "path"
 *      description: "get available balance for any BSC address"
 *      type: "string"
 *      required: true
 *    summary: get available balance for any BSC address
 *    description: to get information of given address valid or not
 *    responses:
 *      '200':
 *        description: response for given address
 * /getbalance/btc/{address}:
 *  get:
 *    parameters:
 *    - name: "address"
 *      in: "path"
 *      description: "get available balance for any BTC address"
 *      type: "string"
 *      required: true
 *    summary: get available balance for any BTC address
 *    description: to get information of given address valid or not
 *    responses:
 *      '200':
 *        description: response for given address
 * /getNewAddress:
 *  get:
 *    summary: get new BTC account address and privatekey 
 *    description: to get information of new generated address
 *    responses:
 *      '200':
 *        description: response for new generated address
 * /tokenTransfer:
 *    post:
 *      summary: to transfer the token based on crypto (ETH/BNB/BTC) coins 
 *      description: ""
 *      consumes:
 *      - "application/json"
 *      produces:
 *      - "application/json"
 *      parameters:
 *      - in: "body"
 *        name: "body"
 *        required: true
 *        schema:
 *            type: object
 *            properties:
 *                coin:
 *                  type: string
 *                  example: ETH/BNB/BTC
 *                transactionId:
 *                  type: integer
 *                  example: 1
 *            required:
 *              - coin
 *              - transactionId  
 *      responses:
 *        200:
 *          description: A JSON packet
 */