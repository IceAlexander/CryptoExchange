'use strict';

module.exports = (sequelize, DataTypes) => {
    var tokentransactions = sequelize.define('tokentransactions', {        
        fromAddress: { 
            type: DataTypes.STRING,
            allowNull: true
        },
        toAddress: { 
            type: DataTypes.STRING,
            allowNull: true
        },
        amount: { 
            type: DataTypes.NUMERIC,
            allowNull: true
        },
        coinTransactionId: { 
            type: DataTypes.STRING,
            allowNull: true
        }, 
        walletId: { 
            type: DataTypes.INTEGER,
            allowNull: true
        },
        status: { 
            type: DataTypes.INTEGER,
            allowNull: true
        },
        errorInfo: { 
            type: DataTypes.TEXT,
            allowNull: true
        },
        createdAt: { 
            type: DataTypes.DATE,
            allowNull: true
        },
        updatedAt: { 
            type: DataTypes.DATE,
            allowNull: true
        }
    });
    tokentransactions.anotherTestFunction = function anotherTestFunction() {
       return "ads";
    }           
  return tokentransactions;
};