'use strict';

module.exports = (sequelize, DataTypes) => {
    var wallets = sequelize.define('wallets', {        
        address: { 
            type: DataTypes.STRING,
            allowNull: true
        },
        privateKey: { 
            type: DataTypes.STRING,
            allowNull: true
        }
    });
    wallets.anotherTestFunction = function anotherTestFunction() {
       return "ads";
    }           
  return wallets;
};