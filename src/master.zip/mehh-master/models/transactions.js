'use strict';

module.exports = (sequelize, DataTypes) => {
    var transactions = sequelize.define('transactions', {        
        paypalTransactionId: { 
            type: DataTypes.STRING,
            allowNull: true
        },
        coinTransactionId: { 
            type: DataTypes.STRING,
            allowNull: true
        },
        amount: { 
            type: DataTypes.NUMERIC,
            allowNull: true
        },
        currency: { 
            type: DataTypes.STRING,
            allowNull: true
        }, 
        status: { 
            type: DataTypes.INTEGER,
            allowNull: true
        },
        email: { 
            type: DataTypes.STRING,
            allowNull: true
        },
        verified: { 
            type: DataTypes.INTEGER,
            allowNull: true
        },
        price:{
            type: DataTypes.NUMERIC,
            allowNull: true
        },
        info:{ 
            type: DataTypes.TEXT,
            allowNull: true
        },
        volume: {
            type:DataTypes.NUMERIC,
            allowNull:true
        },
        createdAt: { 
            type: DataTypes.DATE,
            allowNull: true
        },
        updatedAt: { 
            type: DataTypes.DATE,
            allowNull: true
        },
        address: { 
            type: DataTypes.STRING,
            allowNull: true
        },
        comment: {
            type: DataTypes.STRING,
            allowNull: true
        }
    });
    transactions.anotherTestFunction = function anotherTestFunction() {
       return "ads";
    }           
  return transactions;
};