module.exports = Object.freeze(
    {
        STRIPE:{
          CLIENT : 'pk_live_51Io4sCFq15fvAfo7FNvHnKHB4ASshZeED0JinzrwJUXHRNd3ZeTu9teFwUND1qUW6az16iRunBnrnOdhu6Bp3Tic00OB5feGBY',
          SECRET : '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',          
        },
        NODE : {
          // add your main address and private key from which mehh coin will be transferred 
          HOST : "http://3.97.97.1:8545/",
          SENDERADDRESS : "0x4399be2A90e054fB33885480629EaE54EbdAA729",
          PRIVKEY : '43d2d2a9b26ab94002085ff1188ed0be63b1c66676157c211c6f22b08e59bcf4',
          GAS : '20000000',

          ETH : {
            HOST : "https://ropsten.infura.io/v3/9aa3d95b3bc440fa88ea12eaa4456161",
            GAS : '20000000'
          },

          BNB : {
            HOST : "https://data-seed-prebsc-1-s1.binance.org:8545/",
            GAS : '20000000'
          },

          BITCOIN: {
            //FULLNODEIP: "35.82.206.21",
            FULLNODEIP: "127.0.0.1",
            FULLNODEPORT: "8332",
            USERNAME: "mehhcoinbtcnode",
            PASSWORD: "MehhCoin@BTCNode@)@!",
            WALLETNAME: "MehhUsersWallet",
            MINCONFIRMATIONHOT : 1
          }
        },
        
        COIN:{
          PRICE:1
        },
        COINPAPARIKA:{
          API : 'https://api.coinpaprika.com/v1/coins/mehhcusd-mehhcoin/ohlcv/historical'
        },
        ETH : {
          PUBLIC_RPC : "https://mainnet.infura.io/v3/9aa3d95b3bc440fa88ea12eaa4456161"
        },
        BSC : {
          PUBLIC_RPC : "https://bsc-dataseed.binance.org"
        }
      }

);