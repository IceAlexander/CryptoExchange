const uniqid = require('uniqid');
module.exports = {
  /**
   * @param  {} schema schema defines in schema.js file
   * @description function to validate the request format from schemas defined in Schemas.js file
   */
  ValidationMiddleware(schema){
    return (req,res,next)=>{
      const { error } = schema.validate(req.body); 
      const valid = error == null;
      if (valid) { 
        next(); 
      } else { 
        const { details } = error; 
        const message = details.map(i => i.message).join(',');
        next({status:422,message:message}) 
      }
    }
  },

  /**
   * @param  {} req
   * @param  {} res
   * @param  {} next
   * @description Log new request and set a uuid in req
   */
  LoggingMiddleware(req, res, next){
      req.uuid=uniqid();
      let ip = (req.headers['x-forwarded-for'] || req.connection.remoteAddress).replace('::ffff:','');
      logger.info(`ReqId:${req.uuid} on:${req.url} ip:${ip}`);
      next();
  },
  /**
   * @param  {} req
   * @param  {} res
   * @param  {} next
   * @description middleware for invalid url => redirect to not found page
   */
  NotFoundMiddleware(req, res, next) {
    logger.error(`${req.ip} tried to reach ${req.originalUrl}`);
    res.status(404).send({error: 'Not found'})
  },

  ErrorHandlerMiddleware(err, req, res, next) {
    // set locals, only providing error in development
    res.locals.message = err.message;
    //res.locals.error = req.app.get('env') === 'production' ? err : {};
    if(req.user){
      let requestBody = JSON.stringify(req.body);
      logger.error(`ReqId: ${req.uuid} userid: ${req.user.userid} req: ${requestBody} Message: ${err.message}`);
    }
    if(err.status ==500){
      res.status(500).send({code : 500, message: 'internal error', type:'internal'})
    }
    else if(err.status ==422){
      res.status(422).send({code : 422, message: err.message, type:'validation'})
    }
    else if(err.status ==401){
      res.status(401).send({code : 401, message: err.message, type:'Unauthorized'})
    }
    else if(err.status ==403){
      res.status(403).send({code : 403, message: err.message, type:'Forbidden'})
    }
    else if(err.status ==400){
      res.status(400).send({code : err.code, message: err.message, type:'Bad Request'})
    }
    else{
      res.status(err.status || 500).send({message: 'Something went wrong, We are looking into it', type:'internal'})
    }
    
}
}