module.exports = {
  apps : [{
    name   : 'Mehh Coin Backend Service API',
    script : 'npm',
    args   : 'start'
  }
]
};
