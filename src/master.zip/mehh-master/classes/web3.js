var method    = Mehhcoin.prototype;
var Constant  = require('../config/Constant');
const Web3    = require("web3")

const { create, all } = require('mathjs');
const config = {
  number: 'BigNumber',
  precision: 20
}
const math = create(all, config)

function Mehhcoin(){

}

method.transfer = function(receiveradd,amount){
  return new Promise(function(resolve,reject){
    var privateKey    = Constant.NODE.PRIVKEY;
    var fromAddress   = Constant.NODE.SENDERADDRESS;
    var rpcUrl        = Constant.NODE.HOST;

    const web3 = new Web3(rpcUrl);

    web3.eth.accounts.wallet.add({
      privateKey: privateKey,
      address: fromAddress
    });

    var volume = math.multiply(math.bignumber(amount), math.bignumber('1000000000000000000'));
    var formattedAmount = math.format(volume, {notation: 'fixed'}).toString();

    web3.eth.sendTransaction({ from: fromAddress,
      to:receiveradd,
      value:formattedAmount,
      gas : '21000' })
    .on('transactionHash', function(hash){
      logger.info(`Mehh coin transferred ${receiveradd} ${amount} ${hash}`);
      resolve(hash);
    })
    .on('error', function(error, receipt) {
      logger.error(error);
      reject(error)
    })
  })
}

method.tokenTransfer = function(receiveradd, amount, coin, fromAddress, privateKey){
  return new Promise(function(resolve,reject){
    if(coin == 'ETH'){
      var rpcUrl        = Constant.NODE.ETH.HOST;
    }else if(coin == 'BNB'){
      var rpcUrl        = Constant.NODE.BNB.HOST;
    }

    const web3 = new Web3(rpcUrl);

    web3.eth.accounts.wallet.add({
      privateKey: privateKey,
      address: fromAddress
    });

    var volume = math.multiply(math.bignumber(amount), math.bignumber('1000000000000000000'));
    var formattedAmount = math.format(volume, {notation: 'fixed'}).toString();
    logger.info(`${coin} ${formattedAmount}`);
    web3.eth.sendTransaction({ from: fromAddress,
      to:receiveradd,
      value:formattedAmount,
      gas : '21000' })
    .on('transactionHash', function(hash){
      logger.info(`${coin} coin transferred ${receiveradd} ${amount} ${hash}`);
      resolve(hash);
    })
    .on('error', function(error, receipt) {
      logger.error(error);
      reject(error)
    })
  })
}

module.exports = Mehhcoin;


