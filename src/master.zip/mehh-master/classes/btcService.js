var Constant = require('../config/Constant');
var Bitcoin = require('./Bitcoin.js');

module.exports = {
    
    async getNetworkInfo(req,res,next) {
        var Bitcoin_obj = new Bitcoin();
        Bitcoin_obj.getNetworkInfo().then((networkInfo)=>{
            res.send(networkInfo);
        }).catch((error) => {
            res.send(error);
            logger.error(error); 
        });
    },

    async getNewAddress(req,res,next) {
        var Bitcoin_obj = new Bitcoin();
        Bitcoin_obj.createHDAddress(req.params.label).then((addressInfo)=>{
            res.send(addressInfo);
        }).catch((error) => {
            res.send(error);
            logger.error(error); 
        });
    },

    async validateAddress(req,res,next) {
        var Bitcoin_obj = new Bitcoin();
        Bitcoin_obj.validateAddress(req.params.address).then((addressInfo)=>{
            res.send(addressInfo.isvalid);
        }).catch((error) => {
            res.send(error);
            logger.error(error); 
        });
    },

    async getBalance(req,res,next) {
        var Bitcoin_obj = new Bitcoin();
        Bitcoin_obj.getBalance(req.params.address).then((balance)=>{
            res.send(200,balance);
        }).catch((error) => {
            res.send(error);
            logger.error(error); 
        });
    },

    async getBTCBalanceForOutSideWallet(req,res,next) {
        var Bitcoin_obj = new Bitcoin();
        Bitcoin_obj.getBTCBalanceForOutSideWallet(req.params.address).then((balance)=>{
            res.send(200,balance);
        }).catch((error) => {
            res.send(error);
            logger.error(error); 
        });
    }
}