const Web3 = require("web3")
var Constant = require('../config/Constant');
const web3 = new Web3(new Web3.providers.HttpProvider(Constant.ETH.PUBLIC_RPC));

module.exports = {
   
    async getBalance(req,res,next) {
        let balanace;
        web3.eth.getBalance(req.params.address, function(err, result) {
            if (err) {
                logger.info(err);
            } else {
                res.send(web3.utils.fromWei(result, "ether"))
            }
        })
        res.send(balance);
    }
}