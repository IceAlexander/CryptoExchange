const Joi = require('joi') 
const schemas = { 
    approvePayment:Joi.object().keys({
        volume: Joi.number().required(),
        email:Joi.string().email().required(),
        address: Joi.string().required(),
    }),

    tokenTransfer :Joi.object().keys({
        coin: Joi.string().required(),
        transactionId: Joi.number().required()
    }),

    
  // define all the other schemas below 
}; 
module.exports = schemas;