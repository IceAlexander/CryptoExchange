var Constant = require('../config/Constant');
const stripe = require("stripe")(Constant.STRIPE.SECRET);
const transactions = require('../models').transactions;
var Mehhcoin = require('./web3.js');
const axios = require('axios')

module.exports = {
    async createPayment(req,res,next){
        logger.info(`createPayment `+req.body.email, req.body.volume)
        let price;
        let volume = req.body.volume;
        
        const endDate = new Date()
        const startDate = new Date()
        startDate.setMonth(startDate.getMonth() - 6)
        let historyStart = (startDate.getTime() / 1000).toFixed(0)
        let historyEnd = (endDate.getTime() / 1000).toFixed(0)
        axios.get(`${Constant.COINPAPARIKA.API}?start=${historyStart}&end=${historyEnd}`)
        .then(async (priceRes)=>{
          const data = priceRes.data
          if (data.length > 0) {
          let latest = data[0]
          price = latest.close;
          }else{
            next({
              status:500,
              code:100,
              message:'unable to fetch latest price, please try again'
            })
          }

          // Create a PaymentIntent with the order amount and currency
          amount = parseFloat(volume*price).toFixed(2);
          let stripeAmount = parseInt(amount*100);
          const paymentIntent = await stripe.paymentIntents.create({
            amount: stripeAmount,
            currency: "usd"
          });
          transactions.create({
              paypalTransactionId:paymentIntent.id,
              amount:amount,
              currency:'USD',
              status:0,
              email:req.body.email,
              price:price,
              volume:volume,
              info: JSON.stringify(paymentIntent),
              address:req.body.address         
          }).then((result)=>{
            res.send({
              clientSecret: paymentIntent.client_secret
            });
          }).catch((error) => {
            if(error.original.constraint == "transactions_paypalTransactionId_key"){
              res.status(400).send({
                  code:127,
                  message:"transaction already exist"
              })
            }else{
              next(error)
            }
          }); 
        })
        .catch((error)=>{
          next(error);
        })
        
    },


    stripeWebhook(req, res){
      const event = req.body;
      // Handle the event
      switch (event.type) {
        case 'payment_intent.succeeded':
          const paymentIntent = event.data.object;
          logger.info(`PaymentIntent for ${paymentIntent.amount} was successful!`);
          // Then define and call a method to handle the successful payment intent.
          confirmPayment(paymentIntent);
          break;
        case 'payment_method.attached':
          const paymentMethod = event.data.object;
          // Then define and call a method to handle the successful attachment of a PaymentMethod.
          // handlePaymentMethodAttached(paymentMethod);
          break;
        default:
          // Unexpected event type
          logger.info(`Unhandled event type ${event.type}.`);
      }
    
      // Return a 200 response to acknowledge receipt of the event
      res.send();
    }
};

//private function 
function confirmPayment(paymentIntent){
    //check DB for unverified transactions
    let txnId = paymentIntent.id
    transactions.findOne({
      where:{
        status:0,
        paypalTransactionId: txnId
      }})
      .then((transaction)=>{
        //if transactions found check from paypal for any confirmation
        if(transaction){
          transaction.update({
            status:1
          })
          .then(()=>{
            logger.info(`Transaction approved id DB transId:${txnId}`);
            var Mehhcoin_obj = new Mehhcoin();
            //send transaction on blockchain
            Mehhcoin_obj.transfer(transaction.address,transaction.volume)
            .then((hash)=>{
              transaction.update({
                status:2,
                coinTransactionId:hash
              })
                .then(()=>{
                    logger.info(`Transaction set to 2 transId:${txnId}`)
                }).catch((error) => {
                  logger.error(`Transaction set 2 failed id DB transId:${pTxnId}`);
                  logger.error(error);
              });
            }).catch((error) => {
                logger.error(`coin transfer fail transId:${pTxnId} ${error}`)
                transaction.update({
                  status:3,                })
                  .then(()=>{
                      logger.info(`Transaction set to 3 transId:${pTxnId}`)
                  }).catch((error) =>  {
                    logger.error(`Transaction set 3 failed id DB transId:${pTxnId}`);
                    logger.error(error);
                });  
            });
          })
          .catch((error)=>{
            logger.error(`Transaction failed id DB transId:${pTxnId}`);
            logger.error(error);
          });
        }
      }) 
      .catch((error)=>{
        logger.error('DB calling error'+error);
      });
  }
