var method   = Bitcoin.prototype;
var request  = require("request");
var Constant = require('../config/Constant');

const { create, all } = require('mathjs');
const config = {
  number: 'BigNumber',
  precision: 20
}
const math = create(all, config)

function Bitcoin() {
}

method.getNetworkInfo = function () {
    return new Promise(function (resolve, reject) {
        var params = [];
        getRequest("getnetworkinfo",params)
        .then((response) =>{
            resolve(response);
        }).catch((error)=>{
            reject(error);
        })
    });
}

method.validateAddress = function (walletAddress) {
    return new Promise(function (resolve, reject) {
        var params = [walletAddress];
        getRequest("validateaddress",params)
        .then((response) =>{
            resolve(response);
        }).catch((error)=>{
            reject(error);
        })
    });
}

method.getBTCBalanceForOutSideWallet = function (walletAddress) {
    return new Promise(function (resolve, reject) {
        var options = { 
            method  : 'GET',
            url     : 'https://blockchain.info/balance',
            qs      : { active: walletAddress },
            headers : {}
        };

        request(options, function (error, response, body) {
            if (error) reject(error);
            resolve(body);
        });
    });
}

method.getBalance = function (walletAddress) {
    return new Promise(function (resolve, reject) {
        var params = [walletAddress];
        getRequest("getreceivedbyaddress", params)
        .then((response) =>{
            resolve(response);
        }).catch((error)=>{
            console.log('I have an error :( ' + error);
            reject(error);
        });
    });
}

method.createHDAddress = function (label) {
    return new Promise(function (resolve, reject) {
        var params = [label];
        makeRequest("getnewaddress", params, Constant.NODE.BITCOIN.WALLETNAME)
        .then((newAddress) =>{
            console.log('New Address : '+newAddress);
            var params = [newAddress];
            makeRequest("dumpprivkey", params, Constant.NODE.BITCOIN.WALLETNAME) 
            .then((pivateKey)=>{
                var result ={
                    address: newAddress,
                    privatekey: pivateKey
                };
                resolve(result);
            }).catch((error)=>{
                console.log('I have an error :( ' + error);
                reject(error);
            });
        }).catch((error)=>{
            console.log('I have an error :( ' + error);
            reject(error);
        })
    });
}

method.transfer = function (receiveradd, amount) {
    return new Promise(function (resolve, reject) {
        var params = [ ,Constant.BITCOIN.MINCONFIRMATIONHOT,false];
        makeRequest("getbalance", params, Constant.NODE.BITCOIN.WALLETNAME)
        .then((balance) =>{
            var volume = math.multiply(math.bignumber(amount), math.bignumber('100000000'));
            var formattedAmount = math.format(volume, {notation: 'fixed'}).toString();
            logger.info(`BTC transfer amount ${formattedAmount}`);

            if(balance >= formattedAmount){
                var params = [ receiveradd, formattedAmount, "hot wallet to user wallet", "" , true];
                makeRequest("sendtoaddress", params, Constant.NODE.BITCOIN.WALLETNAME) 
                .then((transactionId)=>{
                    logger.info(`BTC coin transferred ${receiveradd} ${amount} ${transactionId}`);
                    resolve(transactionId);
                    // var params = [transactionId, true];
                    // makeRequest("getrawtransaction", params, Constant.NODE.BITCOIN.WALLETNAME) 
                    // .then((rawtransaction)=>{
                    //     var params = [rawtransaction.hex];
                    //     makeRequest("decoderawtransaction", params, Constant.NODE.BITCOIN.WALLETNAME) 
                    //     .then((transactionDetail)=>{
                    //         let transacIdarray = [];
                    //         for (var inputTransac of transactionDetail.vin){
                    //             transacIdarray.push(inputTransac.txid);
                    //         }
                    //         resolve(transacIdarray);
                    //     }).catch((error)=>{
                    //         reject(error);
                    //     })
                    // }).catch((error)=>{
                    //     reject(error);
                    // });
                }).catch((error)=>{
                    reject(error);
                });
            }else{
                reject('Insufficient balance..');
            }
        }).catch((error)=>{
            reject(error);
        })
    });
}

var makeRequest = function(methodName, paramsList, wallet){
    return new Promise((resolve,reject)=>{

        var base_url = `http://${Constant.NODE.BITCOIN.FULLNODEIP}:${Constant.NODE.BITCOIN.FULLNODEPORT}`;
        var auth     = Buffer.from(Constant.NODE.BITCOIN.USERNAME + ':' + Constant.NODE.BITCOIN.PASSWORD).toString('base64');
        var headers  = {
            "Content-Type"  :   "application/json-rpc",
            "Authorization" :   "Basic " + auth
        }
        let formData = {"jsonrpc":"1.0","method":methodName,"params":paramsList,"id":methodName};
        var options = {
            url: base_url+`/wallet/${wallet}`,
            method: "POST",
            headers: headers,
            user: "bitcoinrpc",
            form: JSON.stringify(formData)
        }

        request(options, function (error, response, body) {
            if (!error && response.statusCode == 200) {
                var data = JSON.parse(body);
                resolve(data.result);

            }else if(!error && response.statusCode == 500){
                logger.error(body)
                reject(error);
            }
            else{
                logger.error(error);
                reject(error);
            }
        })
    })   
}

var getRequest = function(methodName, paramsList){
    return new Promise((resolve,reject)=>{

        var base_url = `http://${Constant.NODE.BITCOIN.FULLNODEIP}:${Constant.NODE.BITCOIN.FULLNODEPORT}`;
        var auth     = Buffer.from(Constant.NODE.BITCOIN.USERNAME + ':' + Constant.NODE.BITCOIN.PASSWORD).toString('base64');
        var headers  = {
            "Content-Type"  :   "application/json-rpc",
            "Authorization" :   "Basic " + auth
        }
        let formData = {"jsonrpc":"1.0","method":methodName,"params":paramsList,"id":methodName};
        var options = {
            url: base_url,
            method: "POST",
            headers: headers,
            user: "bitcoinrpc",
            form: JSON.stringify(formData)
        }

        request(options, function (error, response, body) {
            if (!error && response.statusCode == 200) {
                var data = JSON.parse(body);
                resolve(data.result);

            }else if(!error && response.statusCode == 500){
                logger.error(body);
                console.log('I have an error :( ' + error);
                reject(error);
            }
            else{
                logger.error(error);
                console.log('I have an error :( ' + error);
                reject(error);
            }
        });
        // var bitcoin_rpc = require('node-bitcoin-rpc');
        // bitcoin_rpc.init(Constant.NODE.BITCOIN.FULLNODEIP, Constant.NODE.BITCOIN.FULLNODEPORT, Constant.NODE.BITCOIN.USERNAME, Constant.NODE.BITCOIN.PASSWORD);
        // bitcoin_rpc.call(methodName, [], function (err, res) {
        //   if (err !== null) {
        //     console.log('I have an error :( ' + err);
        //     reject(err);
        //   } else {
        //     console.log('Yay! I need to do whatevere now with ' + res.result);
        //     resolve(res.result);
        //   }
        // })
    })   
}

module.exports = Bitcoin;