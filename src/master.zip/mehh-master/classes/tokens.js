var Constant = require('../config/Constant');
var Mehhcoin = require('./web3.js');
var Bitcoin = require('./Bitcoin.js');

const wallet = require('../models').wallets;
const tokentransactions = require('../models').tokentransactions;

module.exports = {
    tokenTransfer(req,res,next){
      let requestMethod = req.method;

      if(requestMethod == 'POST'){
        var txnId = req.body.transactionId;
        var coin  = req.body.coin;
      }else{
        var txnId = req.params.transactionId;
        var coin  = req.params.coin;
      }

      logger.info(`token transfer request `+coin+` `+txnId);
      
      // Txn Status 0 => pending, 1 => completed, 2 => initiated, 3 => failed
      
      tokentransactions.findOne({ where:{ status:0, id: txnId }}).then((transaction)=>{
        console.log(transaction);
        if(transaction && transaction.walletId && transaction.toAddress && transaction.amount !== null){
          wallet.findOne({ where:{ id: transaction.walletId }}).then((walletInfo)=>{
            if(walletInfo && walletInfo.address && walletInfo.privateKey){
              tokentransactions.update({ status:2 }, { where: { id: txnId } }).then(()=>{
                logger.info(`Transaction data found and updated status to initiated:${coin} ${txnId}`);
                if(coin == 'ETH' || coin == 'BNB'){
                  //send transaction on blockchain
                  var Mehhcoin_obj = new Mehhcoin();
                  Mehhcoin_obj.tokenTransfer(transaction.toAddress, transaction.amount, coin, walletInfo.address, walletInfo.privateKey).then((hash)=>{
                    tokentransactions.update({ status:1, coinTransactionId:hash }, { where: { id: txnId } }).then(()=>{
                      logger.info(`Transaction Hash id generated HashId:${txnId}-${hash}`);
                      res.send({status: true, message: 'success'});
                    }).catch((error) => {
                      logger.error(`Transaction Hash id set failed in DB transId:${txnId}`);
                      logger.error(error);
                      res.send({status: false, message: 'DB Updation Failed'});
                    });
                  }).catch((error) => {
                    logger.error(`coin transfer fail transId:${txnId} ${error}`)
                    tokentransactions.update({ status:3, errorInfo: 'Transaction failed'}, { where: { id: txnId } }).then(()=>{
                      logger.info(`Transaction set to 3 in DB transId:${txnId}`);
                      res.send({status: false, message: 'Transaction Failed'});
                    }).catch((error) =>  {
                      logger.error(`Transaction set 3 failed id DB transId:${txnId}`);
                      logger.error(error);
                      res.send({status: false, message: 'DB Updation Failed'});
                    });  
                  });
                }else if(coin == 'BTC'){
                  // do BTC transaction
                  var Bitcoin_obj = new Bitcoin();
                  Bitcoin_obj.transfer(transaction.toAddress, transaction.amount).then((hash)=>{
                    tokentransactions.update({ status:1, coinTransactionId:hash }, { where: { id: txnId } }).then(()=>{
                      logger.info(`Transaction Hash id generated HashId:${txnId}-${hash}`);
                      res.send({status: true, message: 'success'});
                    }).catch((error) => {
                      logger.error(`Transaction Hash id set failed in DB transId:${txnId}`);
                      logger.error(error);
                      res.send({status: false, message: 'DB Updation Failed'});
                    });
                  }).catch((error) => {
                    logger.error(`coin transfer fail transId:${txnId} ${error}`)
                    tokentransactions.update({ status:3, errorInfo: 'Transaction failed'}, { where: { id: txnId } }).then(()=>{
                      logger.info(`Transaction set to 3 in DB transId:${txnId}`);
                      res.send({status: false, message: 'Transaction failed'});
                    }).catch((error) =>  {
                      logger.error(`Transaction set 3 failed id DB transId:${txnId}`);
                      logger.error(error);
                      res.send({status: false, message: 'DB Updation Failed'});
                    });  
                  });
                }else{
                  logger.error(`coin not applicable to this transaction transId:${txnId}`)
                  tokentransactions.update({ status:3, errorInfo: 'Invalid Coin Token Transfer Request - '+coin}, { where: { id: txnId } }).then(()=>{
                    logger.info(`Transaction set to 3 in DB transId:${txnId}`);
                    res.send({status: false, message: 'Invalid Token Transfer Request'});
                  }).catch((error) =>  {
                    logger.error(`Transaction set 3 failed id DB transId:${txnId}`);
                    logger.error(error);
                    res.send({status: false, message: 'DB Updation Failed'});
                  });
                }
              }).catch((error)=>{
                logger.error(`Transaction set status to 2 failed id DB transId:${txnId}`);
                logger.error(error);
                res.send({status: false, message: 'DB Updation Failed'});
              });
            }else{
              tokentransactions.update({ status:3, errorInfo:'Wallet Info empty'}, { where: { id: txnId } }).then(()=>{
                logger.info(`Transaction failed and set status 3 beacause of wallet info empty:${coin} ${txnId}`);
                res.send({status: false, message: 'Transaction failed'});
              }).catch((error)=>{
                logger.error(`Transaction set status to 3 failed id DB transId:${coin} ${txnId}`);
                logger.error(error);
                res.send({status: false, message: 'DB Updation Failed'});
              });
            }
          }).catch((error)=>{
            logger.error(`Transaction failed to connect wallet table:${coin} ${txnId} ${error}`);
            logger.error(error);
            res.send({status: false, message: 'Transaction failed to connect specified wallet'});
          });
        }else{
          logger.error(`Transaction data empty or invalid and set failed this transaction transId:${txnId}`)
          tokentransactions.update({ status:3, errorInfo: 'Transaction data empty or invalid - '+coin}, { where: { id: txnId } }).then(()=>{
            logger.info(`Transaction set to 3, there is no txn data in DB transId:${txnId}`);
            res.send({status: false, message: 'Transaction failed'});
          }).catch((error) =>  {
            logger.error(`Transaction set 3 failed id DB transId:${txnId}`);
            logger.error(error);
            res.send({status: false, message: 'DB Updation Failed'});
          });
        }
      }).catch((error)=>{
        logger.error('DB calling error'+error);
        logger.error(error);
        res.send({status: false, message: 'DB connection error'});
      });

    }
};
