var express = require('express');
var path = require('path');
var cookieParser = require('cookie-parser');
var cors = require('cors');
var bodyParser = require("body-parser");
var helmet = require('helmet');
var winston = require('winston');
const {format } = require('winston');
var middleware = require('./middleware/Middleware');
require('winston-daily-rotate-file');
var indexRouter = require('./routes/index');

const swaggerJsDoc = require("swagger-jsdoc");
const swaggerUi    = require("swagger-ui-express");
var apipath = path.join(__dirname ,`./routes/*.js`);
//swagger options 
const swaggerOptions = {
  swaggerDefinition: {
    info: {
      title: "Mehh Token Transfer API",
      description: "Mehh Token transfer api information",
      version: '1.0.0',
      servers: ["http://localhost:3000"]
    },
    basePath: "/api"
  },
  apis: [apipath]
};
const swaggerDocs = swaggerJsDoc(swaggerOptions);

var app = express();
const { expressCspHeader, INLINE, NONE, SELF } = require('express-csp-header');

// view engine setup
app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'jade');

/**
 * @param  {} winston.transports.DailyRotateFile
 * @description transport for logger => files kept for 7 days attribute:  maxFiles: '7d'
 */
var transport = new (winston.transports.DailyRotateFile)({
  filename: './logs/appLogs%DATE%.log',
  datePattern: 'YYYY-MM-DD',
  zippedArchive: true,
  maxFiles: '7d',
  maxSize: '20m'
});

global.logger = winston.createLogger({
  transports: [transport],
  format: format.combine(
    format.timestamp({ format: 'YYYY-MM-DD HH:mm:ss' }),
    format.printf(info => `${info.timestamp} ${info.level}: ${info.message}`)
  ),
});

//cors setting 
app.use(cors());
app.use(function (req, res, next) {
  res.header('Access-Control-Allow-Origin', '*');
  res.header('Access-Control-Allow-Methods', 'GET, POST, OPTIONS, PUT, PATCH, DELETE');
  res.header('Access-Control-Allow-Headers', 'X-EXC-APIKEY,content-type'); 
  next();
});

// app.use(helmet());
// app.use(expressCspHeader({
//   directives: {
//       'default-src': [[INLINE],[SELF],'*'],
//       'script-src-elem' : [[INLINE],[SELF],'*']
//   }
// }));

app.use(bodyParser.json()); 
app.use(express.json());
app.use(express.urlencoded({ extended: false }));
app.use(cookieParser());
app.use(express.static(path.join(__dirname, 'public')));

app.use("/api/api-docs", swaggerUi.serve, swaggerUi.setup(swaggerDocs));
app.use('/api/', indexRouter);
app.use('/', indexRouter);

// catch 404 and forward to error handler
app.use(middleware.NotFoundMiddleware);
// error handler
app.use(middleware.ErrorHandlerMiddleware);



module.exports = app;
