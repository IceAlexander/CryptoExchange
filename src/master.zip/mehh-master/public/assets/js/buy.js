alertify.set('notifier', 'position', 'top-right')
const walletElem = document.querySelector('#wallet');
const usdElem = document.querySelector('#amount');
const mehhCoinElem = document.querySelector('#mehhcoin');
const totalPurchaseElem = document.querySelector('#total-purchase');
const buyButton = document.querySelector('#buy-button');
const emailElem = document.querySelector('#email');
const modal = document.querySelector('#stripe-modal');

let usdPurchase = 0

let usdToMehh = () => {
    let usd = parseFloat(usdElem.value);
    let mehhCoinValue = currentPrice > 0 ? usd / currentPrice : 0
    mehhCoinElem.value = mehhCoinValue.toFixed(3)
    totalPurchaseElem.innerText = usd

    usdPurchase = usd
}

let mehhToUsd = () => {
    let mehhCoin = parseFloat(mehhCoinElem.value);
    let usdValue = mehhCoin * currentPrice
    let usdValueFormat = usdValue.toFixed(3)

    usdElem.value = usdValueFormat
    totalPurchaseElem.innerText = usdValueFormat

    usdPurchase = usdValue
}

usdElem.addEventListener('keyup', () => usdToMehh());
usdElem.addEventListener('change', () => usdToMehh());
mehhCoinElem.addEventListener('keyup', () => mehhToUsd());
mehhCoinElem.addEventListener('change', () => mehhToUsd());

buyButton.addEventListener('click', () => {
    let error = false;
    if (walletElem.value === '') {
        alertify.error('Please enter your Wallet ID');
        error = true
    }

    if (emailElem.value === '') {
        alertify.error('Please enter your Email ID');
        error = true
    }

    if (usdPurchase <= 0) {
        alertify.error('Purchase value must be more than $0.00');
        error = true
    }

    if (!error) {
        modal.style.display = "flex";
        // alertify.success('Success');
        console.log({
            wallet: walletElem.value,
            usd: usdPurchase,
        })
        fetchSecretId();
    }

});

window.onclick = function (event) {
    if (event.target == modal) {
        modal.style.display = "none";
    }
}
document.querySelector("button").disabled = true;
async function fetchSecretId() {
    await fetch("https://mehhcoin.com/createPayment/", {
        method: "POST",
        headers: {
            "Content-Type": "application/json",
        },
        body: JSON.stringify({
            "volume": mehhCoinElem.value,
            "email": emailElem.value,
            "address": walletElem.value
        })
    }).then(function (result) {
        return result.json();
    }).then(function (data) {
        document.querySelector("button").disabled = true;
        console.log('is calling');
        var stripe = Stripe('pk_live_51Io4sCFq15fvAfo7FNvHnKHB4ASshZeED0JinzrwJUXHRNd3ZeTu9teFwUND1qUW6az16iRunBnrnOdhu6Bp3Tic00OB5feGBY');
        var elements = stripe.elements();

        var style = {
            base: {
                color: "#32325d",
                fontFamily: 'Arial, sans-serif',
                fontSmoothing: "antialiased",
                fontSize: "16px",
                "::placeholder": {
                    color: "#32325d"
                }
            },
            invalid: {
                fontFamily: 'Arial, sans-serif',
                color: "#fa755a",
                iconColor: "#fa755a"
            }
        };

        var card = elements.create("card", { style: style });
        // Stripe injects an iframe into the DOM
        card.mount("#card-element");

        card.on("change", function (event) {
            // Disable the Pay button if there are no card details in the Element
            document.querySelector("button").disabled = event.empty;
            document.querySelector("#card-error").textContent = event.error ? event.error.message : "";
        });

        var form = document.getElementById("payment-form");
        form.addEventListener("submit", function (event) {
            event.preventDefault();
            // Complete payment when the submit button is clicked
            payWithCard(stripe, card, data.clientSecret);
        });
    });
}
// Calls stripe.confirmCardPayment
// If the card requires authentication Stripe shows a pop-up modal to
// prompt the user to enter authentication details without leaving your page.
var payWithCard = function (stripe, card, clientSecret) {
    loading(true);
    stripe.confirmCardPayment(clientSecret, {
        payment_method: {
            card: card
        }
    })
        .then(function (result) {
            if (result.error) {
                // Show error to your customer
                showError(result.error.message);
            } else {
                // The payment succeeded!
                orderComplete(result.paymentIntent.id);
            }
        });
};

/* ------- Placing Order ------- */

// Shows a success message when the payment is complete
var orderComplete = function (paymentIntentId) {
    loading(false);
    document
        .querySelector(".result-message a")
        .setAttribute(
            "href",
            "https://dashboard.stripe.com/test/payments/" + paymentIntentId
        );
    document.querySelector(".result-message").classList.remove("hidden");
    document.querySelector("button").disabled = true;
};

// Show the customer the error from Stripe if their card fails to charge
var showError = function (errorMsgText) {
    loading(false);
    var errorMsg = document.querySelector("#card-error");
    errorMsg.textContent = errorMsgText;
    setTimeout(function () {
        errorMsg.textContent = "";
    }, 4000);
};

// Show a spinner on payment submission
var loading = function (isLoading) {
    if (isLoading) {
        // Disable the button and show a spinner
        document.querySelector("button").disabled = true;
        document.querySelector("#spinner").classList.remove("hidden");
        document.querySelector("#button-text").classList.add("hidden");
    } else {
        document.querySelector("button").disabled = false;
        document.querySelector("#spinner").classList.add("hidden");
        document.querySelector("#button-text").classList.remove("hidden");
    }
};