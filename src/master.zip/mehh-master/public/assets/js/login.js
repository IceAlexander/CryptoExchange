const loader = document.querySelector('.loader-cover')
const emailElem = document.querySelector('#email')
const passwordElem = document.querySelector('#password')
const loginBtn = document.querySelector('#login-btn')

loginBtn.addEventListener('click', async function(e) {
    loader.classList.add('show')
    const email = emailElem.value
    const password = passwordElem.value

    const data = { email, password }
    let error = false

    if (!data.email) {
        alertify.error('Please enter your email');
        error = true
    }

    if (!data.password) {
        alertify.error('Please enter your password');
        error = true
    }

    if (error) {
        loader.classList.remove('show')
        return false
    }

    try {
        const res = await axios.post('https://api.mehhnetwork.com/auth/login', data) // todo change to live url
        const resData = await res.data

        console.log(resData)
        alertify.success(resData.message)
        localStorage.setItem('token', resData.data.token)
        window.location.href = '/'

        loader.classList.remove('show')
    } catch (e) {
        if (e.response) alertify.error(e.response.data.message)
        else console.log(e.message)

        loader.classList.remove('show')
    }
})