const loader = document.querySelector('.loader-cover')
const emailElem = document.querySelector('#email')
const passwordElem = document.querySelector('#password')
const registerBtn = document.querySelector('#register-btn')

registerBtn.addEventListener('click', async function(e) {
    loader.classList.add('show')
    const email = emailElem.value
    const password = passwordElem.value

    const data = { email, password }
    let error = false

    if (!data.email) {
        alertify.error('Please enter your email');
        error = true
    }

    if (!data.password) {
        alertify.error('Please enter your password');
        error = true
    }

    if (error) {
        loader.classList.remove('show')
        return false
    }

    try {
        const res = await axios.post('https://api.mehhnetwork.com/auth/register', data) // todo change to live url
        const resData = await res.data

        console.log(resData)
        alertify.success(resData.message)
        setTimeout(() => window.location.href = '/login', 2000)

        loader.classList.remove('show')
    } catch (e) {
        if (e.response) alertify.error(e.response.data.message)
        else console.log(e.message)

        loader.classList.remove('show')
    }
})